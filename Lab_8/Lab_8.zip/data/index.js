module.exports = {
    palindrome: require("./palindrome")
}